package com.jkhenfer.Gigatis_Project.Gigatis;

import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;


public class MainActivity extends AppCompatActivity {
    private TextInputLayout textInputEmail;
    private TextInputLayout textInputUsername;
    private TextInputLayout textInputPassword;
    private Button button;


    // [START declare_analytics]
    private FirebaseAnalytics mFirebaseAnalytics;
    // [END declare_analytics]


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // make the activity on full screen

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);


        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);


        // Log events
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.LOGIN, null);



        TextView textView = findViewById(R.id.textView2);

        String text = "By signing up, you agree to our Terms of Use and Privacy Policy.";

        SpannableString ss = new SpannableString(text);



        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Toast.makeText(MainActivity.this, "These Terms of Service constitute a legally binding agreement between you and Gigatis, Inc. (“Gigatis”) governing your use of the Gigatis Platform. Gigatis’ websites (including https://www.gigatis.com, www.gigatis.co.uk, www.gigatis.ca, and www.Gigatis.fr) (the “Sites”), mobile applications (the “Apps”), and related services, information and communications are collectively referred to as the “Gigatis Platform.”\n" +
                        "The use of all personal data you submit to the Gigatis Platform or which we collect about you is governed by our Global Privacy Policy (“Privacy Policy”). A copy of our Privacy Policy is available on our websites. You acknowledge that by using the Gigatis Platform you have reviewed the Privacy Policy.\n" +
                        "Your consent at registration and continued use of the Gigatis Platform constitutes your acceptance of and agreement to all of the terms and conditions in these Global Terms of Service, the Privacy Policy, and the Gigatis Happiness Pledge (the “Happiness Pledge”) for the country in which the Gig is performed, as well as any future amendments and additions to this Agreement (as defined below) as we may publish from time to time.\n" +
                        "If you do not agree to be bound by this agreement and abide by its terms, you may not use or access the Gigatis platform.\n", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(true);
            }
        };

        ss.setSpan(clickableSpan1, 32, 63, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());


        // hide the action bar

        getSupportActionBar().hide();

        textInputEmail = findViewById(R.id.text_input_email);
        textInputUsername = findViewById(R.id.text_input_username);
        textInputPassword = findViewById(R.id.text_input_password);
    }

    private boolean validateEmail() {
        String emailInput = textInputEmail.getEditText().getText().toString().trim();

        // [START custom_event]
        Bundle params = new Bundle();
        params.putString("email", emailInput);
        mFirebaseAnalytics.logEvent("id_email", params);
        // [END custom_event]

        if (emailInput.isEmpty()) {
            textInputEmail.setError("Field can't be empty.");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            textInputEmail.setError("Invalid email address.");
            return false;
        } else {
            textInputEmail.setError(null);
            return true;
        }
    }

    private boolean validateUsername() {
        String usernameInput = textInputUsername.getEditText().getText().toString().trim();

        // [START custom_event]
        Bundle params = new Bundle();
        params.putString("username", usernameInput);
        mFirebaseAnalytics.logEvent("id_username", params);
        // [END custom_event]

        if (usernameInput.isEmpty()) {
            textInputUsername.setError("Field can't be empty.");
            return false;
        } else if (usernameInput.length() > 30) {
            textInputUsername.setError("Username too long.");
            return false;
        } else {
            textInputUsername.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        // [START custom_event]
        Bundle params = new Bundle();
        params.putString("password", passwordInput);
        mFirebaseAnalytics.logEvent("id_password", params);
        // [END custom_event]

        if (passwordInput.isEmpty()) {
            textInputPassword.setError("Field can't be empty.");
            return false;
        } else {
            textInputPassword.setError(null);
            return true;
        }

    }


    public void confirmInput(View v) {
        if (!validateEmail() | !validateUsername() | !validatePassword()) {
            return;
        }

        String input = "Username: " + textInputUsername.getEditText().getText().toString();
        input += "\n";
        input += "Email: " + textInputEmail.getEditText().getText().toString();
        input += "\n";
        input += "Password: " + textInputPassword.getEditText().getText().toString();

        //Toast.makeText(this, input, Toast.LENGTH_SHORT).show();

        openDialog();

        textInputUsername.getEditText().getText().clear();
        textInputEmail.getEditText().getText().clear();
        textInputPassword.getEditText().getText().clear();



        // [START custom_event]
        Bundle params = new Bundle();
        params.putString("input", input);
        mFirebaseAnalytics.logEvent("input", params);
        // [END custom_event]


    button = findViewById(R.id.button);
    button.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            openDialog();

            textInputUsername.getEditText().getText().clear();
            textInputEmail.getEditText().getText().clear();
            textInputPassword.getEditText().getText().clear();



            // [START custom_event]
            Bundle params = new Bundle();
            params.putString("su_button", String.valueOf(button));
            mFirebaseAnalytics.logEvent("su_button", params);
            // [END custom_event]
        }



    });

    }


    public void openDialog() {
        DialogueBox dialogueBox = new DialogueBox();
        dialogueBox.show(getSupportFragmentManager(), "service failure");

        Bundle params = new Bundle();
        params.putString("error_message", String.valueOf(dialogueBox));
        mFirebaseAnalytics.logEvent("error_message", params);

    }



}
